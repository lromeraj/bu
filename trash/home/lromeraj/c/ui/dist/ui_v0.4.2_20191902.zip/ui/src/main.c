#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ui.h"

enum { BOX1, BOX2 };

int main() {

  Ui *ui = ui_init(50,20);

  ui_bg( ui, BG_BLUE );

  ui_new_box( ui, BOX1, 0, 0, 50, 6 );
  ui_new_box( ui, BOX2, 0, 7, 30, 5 );

  ui_box_pad( ui, BOX1, "1 1 1 1" );
  ui_box_bg( ui, BOX1, BG_WHITE );
  ui_box_bg( ui, BOX2, BG_BLACK );

  ui_frm( ui, 2, FG_WHITE, BG_BLUE );
  ui_box_put( ui, BOX1, "\tBOX1 @HEADER\n" );
  ui_rs( ui );
  ui_box_put( ui, BOX1, " - Some text\n - Some more text\n - Uhuuuu");

  ui_frm( ui, 3, BG_GREEN, FG_BLACK, S_BOLD );
  ui_box_put( ui, BOX2, "@BOX2 :)\n");
  ui_frm( ui, 1, FG_WHITE, BG_BLUE );
  ui_box_put( ui, BOX2, " @Style1\n");
  ui_frm( ui, 1, BG_PURPLE );
  ui_box_put( ui, BOX2, " @Style2\n");


  ui_draw( ui );

  return 0;
}
