# UI - User interface based on chars
