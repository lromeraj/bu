#include <stdio.h>
#include <stdlib.h>

int main( int argc, char *argv[] ) {

	printf("let's build awesome code!\n");

	return 0;
}
