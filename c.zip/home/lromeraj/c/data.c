hola
adios
pepito
ajajajaja
ok
vale
nice
ole ole ole ole
