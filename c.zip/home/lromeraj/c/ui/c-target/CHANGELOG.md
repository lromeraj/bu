## v0.5.3
`[FIXES]`
- Fixed a bug that caused parsing errors 
	when comments were present in the configuration file.

`[IMPROVEMENTS]`
- Improved `_comp()` function. This function now detects if it is necesary
	to recompile other files ehn modifying others.
