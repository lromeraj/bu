# C-target

## Install
- First  clone the repo:
``` 
$ git clone https://github.com/lromeraj/c-target 
```
- Go inside project directory
```
$ cd c-target 
``` 
- And finally install it
```
$ make install
```

## Usage
