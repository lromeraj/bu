#include <stdio.h>
#include <stdlib.h>

#define N 10
#define M 10

void a( int c[N][M], int d[N][M] );


void a( int c[N][M], int d[N][M] ) {
	c[ 0 ][ 0 ] = d[ 0 ][ 0 ];
}





int main() {



}
