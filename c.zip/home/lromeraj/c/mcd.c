#include <stdio.h>


int mcd(int a, int b) {

  int d;


  return d;
}

int main() {


  return 0;

}
